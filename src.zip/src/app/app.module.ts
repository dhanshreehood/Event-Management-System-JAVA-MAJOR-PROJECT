import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AddCategoryComponent } from './components/add-category/add-category.component';
import { AllCategoryComponent } from './components/all-category/all-category.component';
import { EditCategoryComponent } from './components/edit-category/edit-category.component';
import { AddEventComponent } from './components/add-event/add-event.component';
import { EventOrganizerNavbarComponent } from './components/event-organizer-navbar/event-organizer-navbar.component';
import { AllEventComponent } from './components/all-event/all-event.component';
import { EditEventComponent } from './components/edit-event/edit-event.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import { RegistrationComponent } from './components/registration/registration.component';
import { AddOfferComponent } from './components/add-offer/add-offer.component';
import { EditOfferComponent } from './components/edit-offer/edit-offer.component';
import { UserNavbarComponent } from './components/user-navbar/user-navbar.component';
import { UpdatePasswordComponent } from './components/update-password/update-password.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { ViewEventsToUserComponent } from './components/view-events-to-user/view-events-to-user.component';
import { SearchEventComponent } from './components/search-event/search-event.component';
import { SortEventPriceDescComponent } from './components/sort-event-price-desc/sort-event-price-desc.component';
import { SortEventPriceAscComponent } from './components/sort-event-price-asc/sort-event-price-asc.component';
import { FilterComponent } from './components/filter/filter.component';
import { AddComplaintComponent } from './components/add-complaint/add-complaint.component';
import { ViewComplaintToOrganizerComponent } from './components/view-complaint-to-organizer/view-complaint-to-organizer.component';
import { ViewComplaintToUserComponent } from './components/view-complaint-to-user/view-complaint-to-user.component';
import { AddFeedbackComponent } from './components/add-feedback/add-feedback.component';
import { AllFeedbackComponent } from './components/all-feedback/all-feedback.component';
import { MainHomePageComponent } from './components/main-home-page/main-home-page.component';
import { UpdateComplaintComponent } from './components/update-complaint/update-complaint.component';
import { LoginComponent } from './components/login/login.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { BookingHistoryUserComponent } from './components/booking-history-user/booking-history-user.component';
import { UpdateBookingStatusComponent } from './components/update-booking-status/update-booking-status.component';
import { AddBookingComponent } from './components/add-booking/add-booking.component';
import { ViewBookingStatusOrganizerComponent } from './components/view-booking-status-organizer/view-booking-status-organizer.component';
import { EventBookingDetailsComponent } from './components/event-booking-details/event-booking-details.component';
import { SearchPipe } from './utility/search.pipe';
import { AddAdminComponent } from './components/add-admin/add-admin.component';
import { AllUserComponent } from './components/all-user/all-user.component';
import { UpdateUserBookingStatusComponent } from './components/update-user-booking-status/update-user-booking-status.component';
import { LogoutComponent } from './components/logout/logout.component';
import { CommonModule } from '@angular/common';
import { AllOrganizerComponent } from './components/all-organizer/all-organizer.component';
import { AdminBookingHistoryComponent } from './components/admin-booking-history/admin-booking-history.component';
import { AdminAllEventListComponent } from './components/admin-all-event-list/admin-all-event-list.component';
import { RouterModule } from '@angular/router';
import { AllOfferOrganierComponent } from './components/all-offer-organier/all-offer-organier.component';
import { LoginRegistrationNavbarComponent } from './components/login-registration-navbar/login-registration-navbar.component';
import { BgAdminNavbarComponent } from './components/bg-admin-navbar/bg-admin-navbar.component';
import { BgOrganizerNavbarComponent } from './components/bg-organizer-navbar/bg-organizer-navbar.component';
import { BgUserNavbarComponent } from './components/bg-user-navbar/bg-user-navbar.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AddCategoryComponent,
    AllCategoryComponent,
    EditCategoryComponent,
    AddEventComponent,
    EventOrganizerNavbarComponent,
    AllEventComponent,
    EditEventComponent,
    RegistrationComponent,
    AddOfferComponent,
    EditOfferComponent,
    UserNavbarComponent,
    UpdatePasswordComponent,
    UpdateProfileComponent,
    ViewEventsToUserComponent,
    SearchEventComponent,
    SortEventPriceDescComponent,
    SortEventPriceAscComponent,
    FilterComponent,
    AddComplaintComponent,
    ViewComplaintToOrganizerComponent,
    ViewComplaintToUserComponent,
    AddFeedbackComponent,
    AllFeedbackComponent,
    MainHomePageComponent,
    UpdateComplaintComponent,
    LoginComponent,
    PageNotFoundComponent,
    BookingHistoryUserComponent,
    UpdateBookingStatusComponent,
    AddBookingComponent,
    ViewBookingStatusOrganizerComponent,
    EventBookingDetailsComponent,
    SearchPipe,
    AddAdminComponent,
    AllUserComponent,
    UpdateUserBookingStatusComponent,
    LogoutComponent,
    AllOrganizerComponent,
    AdminBookingHistoryComponent,
    AdminAllEventListComponent,
    AllOfferOrganierComponent,
    LoginRegistrationNavbarComponent,
    BgAdminNavbarComponent,
    BgOrganizerNavbarComponent,
    BgUserNavbarComponent,
    

  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatInputModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationFormService } from 'src/app/utility/registration-form.service';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent {

  message: any;
  msg:any;
  constructor(private _fb: FormBuilder, 
    private _router: Router, 
    private _registrationFormService: RegistrationFormService) { }

  registerForm: FormGroup = this._fb.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    firstName: ['', [Validators.required, Validators.minLength(3)]],
    lastName: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
    address: ['', [Validators.required, Validators.minLength(6)]],
    contactNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
    role: ['', Validators.required]    
  });

  ngOnInit(): void {
  }

  registration() {
    this._registrationFormService.registration(this.registerForm.value).subscribe(response => { console.log(response); 
      this.message = response

    },
      (error)=>{
        this.msg = error;
        alert(this.msg.error);
        console.log(this.msg.error);
      }
      );

    console.log(this.registerForm.value);

    // to reset registration form after submit
      this.registerForm.reset()
  }
}
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { OfferService } from 'src/app/utility/offer.service';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.css']
})
export class AddBookingComponent {

  id:any;
  message:any;
  offers:any;
  events:any;

  userId:any;
  register:any;

  constructor(private _route:Router, 
              private _eventOrganizerService:EventOrganizerService , 
              private _fb:FormBuilder, 
              private _bookingService:BookingService,
              private _offerService:OfferService,
              private _activatedRoute:ActivatedRoute,
              private _userService:UserService) {
      this.offers = [], this.events = []
   }

  ngOnInit(): void {
    this._offerService.getAllOffer().subscribe(data => {console.log(data);
      this.offers=data;});

      //get user data by user id
      this.userId=sessionStorage.getItem('registrationId');
      console.log(this.userId);
      this.register = this._userService.getUserById(this.userId).subscribe((response:any)=>(this.register = response));
      console.log(this.register);

      //get event by id
      this._activatedRoute.params.subscribe(params => {
        this.id = params['id'];
        console.log("id "+this.id);
        
      // this.events = this._eventOrganizerService.getEventById(this.id);
       this._eventOrganizerService.getEventById(this.id).subscribe(data => {console.log(data);
        this.events=data;});
  
      });
  }

  addBookingForm:FormGroup = this._fb.group({
    bookingStatus:[''],
    userBookingStatus:[''],
    event:[''],
    user:[''],
    offer:[''],
    eventOrganizer:['']
  });

  addBooking()
  {
    this._bookingService.addBooking(this.addBookingForm.value).subscribe(response => {console.log(response); this.message = response});
    console.log(this.addBookingForm.value);
    
    setTimeout(() => {
      this._route.navigate(['/userNavbar']);
    }, 1000);
}

}
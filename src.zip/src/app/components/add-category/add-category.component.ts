import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/utility/user.service';


@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {

  message:any;
  categories:any;
  
  adminId:any;
  register:any;

  msg:any;

  constructor(private _route:Router, 
    private _adminCategoryService:AdminCategoryService, 
    private _userService:UserService,
    private _fb:FormBuilder) { 
  }

  ngOnInit(): void { 

    //get admin by id
    this.adminId=sessionStorage.getItem('registrationId');
    console.log(this.adminId);
    this.register = this._userService.getUserById(this.adminId).subscribe((response:any)=>(this.register = response));
    console.log(this.register);

  }

  addCategoryForm:FormGroup = this._fb.group({
    categoryName:[''],
    admin:['']
  });

  addCategory()
  {
    this._adminCategoryService.addCategory(this.addCategoryForm.value).subscribe(response => {console.log(response); this.message = response},
    (error)=>{
      this.msg = error;
      alert(this.msg.error);
      console.log(this.msg.error);
    }
    );

    this.addCategoryForm.reset()

   setTimeout(() => {
    this._route.navigate(['/getAllCategory']);
  }, 1000);
  }

}

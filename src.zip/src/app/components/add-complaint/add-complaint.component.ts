import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';
import { ComplaintService } from 'src/app/utility/complaint.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-add-complaint',
  templateUrl: './add-complaint.component.html',
  styleUrls: ['./add-complaint.component.css']
})
export class AddComplaintComponent {

  message:any;
  events:any;

  userId:any;
  register:any;

  constructor(private _route:Router, 
    private _eventOrganizerService:EventOrganizerService , 
    private _fb:FormBuilder, 
    private _userService:UserService,
    private _complaintService:ComplaintService) {
    this.events = []
   }

  ngOnInit(): void {
    this._eventOrganizerService.getAllEvent().subscribe(data => {console.log(data);
      this.events=data;});

    //get user by id
    this.userId=sessionStorage.getItem('registrationId');
    console.log(this.userId);
    this.register = this._userService.getUserById(this.userId).subscribe((response:any)=>(this.register = response));
    console.log(this.register);
  }

  addComplaintForm:FormGroup = this._fb.group({
    complaintDiscription:[''],
    complaintStatus:[''],
    userComplaint:[''],
    eventNameId:[''],
    eventOrganizer:['']
  });

  // complaintDiscription:string;
  // complaintStatus:string;
  // userComplaint:object;
  // eventNameId:object;
  // eventOrganizer:object;

  addComplaint()
  {
    this._complaintService.addComplaint(this.addComplaintForm.value).subscribe(response => {console.log(response); this.message = response});
    console.log(this.addComplaintForm.value);
    
    setTimeout(() => {
      this._route.navigate(['/viewComplaintToUser']);
    }, 1000);
  }

}
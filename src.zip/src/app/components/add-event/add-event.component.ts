import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.css']
})
export class AddEventComponent implements OnInit {

  message:any;
  events:any;
  categories:any;
  currentDate:any = new Date();

  organizerId:any;
  register:any;
  

  constructor(private _route:Router, 
              private _eventOrganizerService:EventOrganizerService , 
              private _fb:FormBuilder, 
              private _userService:UserService,
              private _adminCategoryService:AdminCategoryService) {
    this.categories = []
   }

  ngOnInit(): void {
    this.organizerId=sessionStorage.getItem('registrationId');
    console.log(this.organizerId);
    this.register = this._userService.getUserById(this.organizerId).subscribe((response:any)=>(this.register = response));
    console.log(this.register);
    
    this._adminCategoryService.getAllCategory().subscribe(data => {console.log(data);
      this.categories=data;});
  }

  addEventForm:FormGroup = this._fb.group({
    eventCategory:[''],
    eventName:[''],
    eventDescription:[''],
    eventDate:[''],
    eventLocation:[''],
    eventPrice:[''],
    eventOrganizer:['']
  });

  addEvent()
  {
    this._eventOrganizerService.addEvent(this.addEventForm.value).subscribe(response => {console.log(response); this.message = response});
    console.log(this.addEventForm.value);
    
    this.addEventForm.reset()

    setTimeout(() => {
      this._route.navigate(['/getAllEvent']);
    }, 1000);
  }

}

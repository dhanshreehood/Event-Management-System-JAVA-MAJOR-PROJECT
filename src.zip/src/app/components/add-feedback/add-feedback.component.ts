import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FeedbackService } from 'src/app/utility/feedback.service';

@Component({
  selector: 'app-add-feedback',
  templateUrl: './add-feedback.component.html',
  styleUrls: ['./add-feedback.component.css']
})
export class AddFeedbackComponent {

  message:any;
  feedBacks:any;

  constructor(private _route:Router, private _feedbackService:FeedbackService , private _fb:FormBuilder) {
    this.feedBacks = []
   }

  ngOnInit(): void {

    this._feedbackService.getAllFeedback().subscribe(data => {console.log(data);
      this.feedBacks=data;});
  }

  addFeedbackForm:FormGroup = this._fb.group({
    feedbackId:[''],
    rating:[''],
    feedback:['']
  });

  addFeedback()
  {
    this._feedbackService.addFeedback(this.addFeedbackForm.value).subscribe(response => {console.log(response); this.message = response});
    console.log(this.addFeedbackForm.value);
    
    this.addFeedbackForm.reset()

    setTimeout(() => {
      this._route.navigate(['/userNavbar']);
    }, 1000);
  }
}
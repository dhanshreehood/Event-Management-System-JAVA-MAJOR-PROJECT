import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OfferService } from 'src/app/utility/offer.service';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-add-offer',
  templateUrl: './add-offer.component.html',
  styleUrls: ['./add-offer.component.css']
})
export class AddOfferComponent {

  message:any;
  offers:any;

  organizerId:any;
  register:any;

  constructor(private _route:Router, private _fb:FormBuilder, 
    private _offerService:OfferService,
    private _userService:UserService) { }

  ngOnInit(): void {

    this.organizerId=sessionStorage.getItem('registrationId');
    console.log(this.organizerId);
    this.register = this._userService.getUserById(this.organizerId).subscribe((response:any)=>(this.register = response));
    console.log(this.register);

  }

  addOfferForm:FormGroup = this._fb.group({
    offerName:[''],
    eventOrganizer:['']
  });

  addOffer()
  {
    this._offerService.addOffer(this.addOfferForm.value).subscribe((response: any) => {console.log(response); this.message = response});

    this.addOfferForm.reset()

    setTimeout(() => {
      this._route.navigate(['/getAllOffer']);
  },1000);

}
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAllEventListComponent } from './admin-all-event-list.component';

describe('AdminAllEventListComponent', () => {
  let component: AdminAllEventListComponent;
  let fixture: ComponentFixture<AdminAllEventListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAllEventListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminAllEventListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

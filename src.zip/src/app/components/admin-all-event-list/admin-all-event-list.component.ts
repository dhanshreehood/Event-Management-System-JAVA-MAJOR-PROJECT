import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';

@Component({
  selector: 'app-admin-all-event-list',
  templateUrl: './admin-all-event-list.component.html',
  styleUrls: ['./admin-all-event-list.component.css']
})
export class AdminAllEventListComponent {

  events:any;

  constructor(private _router:Router, private _eventOrganizerService:EventOrganizerService) { }

  ngOnInit(): void {
    this._eventOrganizerService.getAllEvent().subscribe(data => {console.log(data);
      this.events=data;});
  }

  getEventById(eventId:number)
  {
    this._eventOrganizerService.getEventById(eventId).subscribe(data => {console.log(data)});
    this._router.navigate(['/editEvent/'+eventId]);
  }

  deleteEvent(eventId:number)
  {
    this._eventOrganizerService.deleteEvent(eventId).subscribe(data => {console.log(data)});
    location.reload();
  }

}

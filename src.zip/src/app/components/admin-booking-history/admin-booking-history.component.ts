import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';

@Component({
  selector: 'app-admin-booking-history',
  templateUrl: './admin-booking-history.component.html',
  styleUrls: ['./admin-booking-history.component.css']
})
export class AdminBookingHistoryComponent {
  booking:any;

  constructor(private _router:Router, 
    private _bookingService:BookingService) { }

  ngOnInit(): void {
    this._bookingService.getAllBooking().subscribe(data => {console.log(data);
      this.booking=data;});
  }
}

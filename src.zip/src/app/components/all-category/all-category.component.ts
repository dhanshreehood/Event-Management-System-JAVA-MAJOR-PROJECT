import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';

@Component({
  selector: 'app-all-category',
  templateUrl: './all-category.component.html',
  styleUrls: ['./all-category.component.css']
})
export class AllCategoryComponent implements OnInit {

  categories:any;
  text:any = "Press OK to Confirm / Press Cancel";

  constructor(private _router:Router, 
    private _adminCategoryService:AdminCategoryService) { }

  ngOnInit(): void {
    this._adminCategoryService.getAllCategory().subscribe(data => {console.log(data);
    this.categories=data;});
  }

  getAllCategory(categoryId:number)
  {
    this._router.navigate(['/getAllCategory/'+categoryId])
  }

  getCategoryById(categoryId:number)
  {
    this._adminCategoryService.getCategoryById(categoryId).subscribe(data => {console.log(data)});
    this._router.navigate(['/editCategory/'+categoryId]);
  }

  deleteCategory(categoryId:number)
  {
    if (confirm(this.text) == true) {
    this._adminCategoryService.deleteCategory(categoryId).subscribe(data => {console.log(data)});
    location.reload();
    }
    else{
      alert("You canceled!");
    }
  }

}

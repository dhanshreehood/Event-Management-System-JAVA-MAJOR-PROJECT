import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { IEventOrganizer } from 'src/app/utility/IEventOrganizer';

@Component({
  selector: 'app-all-event',
  templateUrl: './all-event.component.html',
  styleUrls: ['./all-event.component.css']
})
export class AllEventComponent implements OnInit {

  events:any;
  text:any = "Press OK to Confirm / Press Cancel";
  // eventss=["asasa","asasas","sasas"];

  organizerId:any;

  constructor(private _router:Router, 
    private _eventOrganizerService:EventOrganizerService) { }

  ngOnInit(): void {

    this.organizerId=sessionStorage.getItem('registrationId');-
    console.log(this.organizerId);
    this._eventOrganizerService.getEventListByOrganizerId(this.organizerId).subscribe(data => {console.log("data =>"+typeof data);
      this.events=data;});

  }

  getEventById(eventId:number)
  {
    this._eventOrganizerService.getEventById(eventId).subscribe(data => {console.log(data)});
    this._router.navigate(['/editEvent/'+eventId]);
  }

  deleteEvent(eventId:number)
  {
    if (confirm(this.text) == true) {
    this._eventOrganizerService.deleteEvent(eventId).subscribe(data => {console.log(data)});
    location.reload();
    }
    else{
      alert("You canceled!");
    }
  }

}
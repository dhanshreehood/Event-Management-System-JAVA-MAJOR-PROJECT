import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackService } from 'src/app/utility/feedback.service';

@Component({
  selector: 'app-all-feedback',
  templateUrl: './all-feedback.component.html',
  styleUrls: ['./all-feedback.component.css']
})
export class AllFeedbackComponent {

  feedbacks:any;

  constructor(private _router:Router, private _feedbackService:FeedbackService) { }

  ngOnInit(): void {
    this._feedbackService.getAllFeedback().subscribe(data => {console.log(data);
      this.feedbacks=data;});
  }

}

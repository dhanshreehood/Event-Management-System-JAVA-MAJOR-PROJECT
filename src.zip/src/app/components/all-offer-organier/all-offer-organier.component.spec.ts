import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllOfferOrganierComponent } from './all-offer-organier.component';

describe('AllOfferOrganierComponent', () => {
  let component: AllOfferOrganierComponent;
  let fixture: ComponentFixture<AllOfferOrganierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllOfferOrganierComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllOfferOrganierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

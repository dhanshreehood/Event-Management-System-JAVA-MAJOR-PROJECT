import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { OfferService } from 'src/app/utility/offer.service';

@Component({
  selector: 'app-all-offer-organier',
  templateUrl: './all-offer-organier.component.html',
  styleUrls: ['./all-offer-organier.component.css']
})
export class AllOfferOrganierComponent {
  offers:any;
  text:any = "Press OK to Confirm / Press Cancel";

  organizerId:any;

  constructor(private _router:Router, 
    private _offerService:OfferService) { }

  ngOnInit(): void {

    this.organizerId=sessionStorage.getItem('registrationId');-
    console.log(this.organizerId);
    this._offerService.getOfferByOrganizerId(this.organizerId).subscribe(data => {console.log("data =>"+typeof data);
      this.offers=data;});

  }

  getOfferById(offerId:number)
  {
    this._offerService.getOfferById(offerId).subscribe(data => {console.log(data)});
    this._router.navigate(['/editOffer/'+offerId]);
  }

  deleteOffer(offerId:number)
  {
    if (confirm(this.text) == true) {
    this._offerService.deleteOffer(offerId).subscribe(data => {console.log(data)});
    location.reload();
    }
    else{
      alert("You canceled!");
    }
  }

}

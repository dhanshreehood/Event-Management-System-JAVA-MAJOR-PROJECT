import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { OfferService } from 'src/app/utility/offer.service';

@Component({
  selector: 'app-all-offer',
  templateUrl: './all-offer.component.html',
  styleUrls: ['./all-offer.component.css']
})
export class AllOfferComponent {
  offers:any;
  constructor(private _router:Router, private _offerService:OfferService) { }

  ngOnInit(): void {
    this._offerService.getAllOffer().subscribe(data => {console.log(data);
    this.offers=data;});
  }

  getAllOffer(offerId:number)
  {
    this._router.navigate(['/getAllOffer/'+offerId])
  }

  getOfferById(offerId:number)
  {
    this._offerService.getOfferById(offerId).subscribe(data => {console.log(data)});
    this._router.navigate(['/editOffer/'+offerId]);
  }

  deleteOffer(offerId:number)
  {
    this._offerService.deleteOffer(offerId).subscribe(data => {alert("Are you Sure?")});
    location.reload();
  }

}

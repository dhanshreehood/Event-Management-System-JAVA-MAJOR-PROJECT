import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AllRegisteredUsersService } from 'src/app/utility/all-registered-users.service';

@Component({
  selector: 'app-all-organizer',
  templateUrl: './all-organizer.component.html',
  styleUrls: ['./all-organizer.component.css']
})
export class AllOrganizerComponent {

  organizer:any;
  text:any= "Press OK to Confirm / Press Cancel";

  constructor(private _router:Router, 
    private _Service:AllRegisteredUsersService) { }

  ngOnInit(): void {
    this._Service.getByOrganizer().subscribe(data => {console.log(data);
    this.organizer=data;});
  }

  //confirm window to make sure if admin wants to delete data or not
  deleteUser(eventId:number){

  if (confirm(this.text) == true) {
    this._Service.deleteUser(eventId).subscribe(data => {console.log(data)});
    location.reload();  
  } 
  else {
    alert("You canceled!");
  }
}
}

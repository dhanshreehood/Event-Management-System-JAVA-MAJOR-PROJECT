import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AllRegisteredUsersService } from 'src/app/utility/all-registered-users.service';

@Component({
  selector: 'app-all-user',
  templateUrl: './all-user.component.html',
  styleUrls: ['./all-user.component.css']
})
export class AllUserComponent {
  user:any;
  text:any= "Press OK to Confirm / Press Cancel";

  constructor(private _router:Router, 
    private _Service:AllRegisteredUsersService) { }

  ngOnInit(): void {
    this._Service.getByUser().subscribe(data => {console.log(data);
    this.user=data;});
  }

  //confirm window to make sure if admin wants to delete data or not
  deleteUser(eventId:number){

  if (confirm(this.text) == true) {
    this._Service.deleteUser(eventId).subscribe(data => {console.log(data)});
    location.reload();  
  } 
  else {
    alert("You canceled!");
  }
}

}

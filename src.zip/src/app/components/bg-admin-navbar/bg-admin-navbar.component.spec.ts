import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BgAdminNavbarComponent } from './bg-admin-navbar.component';

describe('BgAdminNavbarComponent', () => {
  let component: BgAdminNavbarComponent;
  let fixture: ComponentFixture<BgAdminNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BgAdminNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BgAdminNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

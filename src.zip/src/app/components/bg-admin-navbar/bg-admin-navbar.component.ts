import { Component } from '@angular/core';

@Component({
  selector: 'app-bg-admin-navbar',
  templateUrl: './bg-admin-navbar.component.html',
  styleUrls: ['./bg-admin-navbar.component.css']
})
export class BgAdminNavbarComponent {
  constructor() { }

  adminName: any;

  ngOnInit(): void {
    this.adminName=sessionStorage.getItem('firstName');
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BgOrganizerNavbarComponent } from './bg-organizer-navbar.component';

describe('BgOrganizerNavbarComponent', () => {
  let component: BgOrganizerNavbarComponent;
  let fixture: ComponentFixture<BgOrganizerNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BgOrganizerNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BgOrganizerNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

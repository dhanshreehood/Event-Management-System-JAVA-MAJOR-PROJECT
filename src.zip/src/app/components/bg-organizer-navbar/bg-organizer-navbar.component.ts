import { Component } from '@angular/core';

@Component({
  selector: 'app-bg-organizer-navbar',
  templateUrl: './bg-organizer-navbar.component.html',
  styleUrls: ['./bg-organizer-navbar.component.css']
})
export class BgOrganizerNavbarComponent {
  constructor() { }

  organizerName: any;

  ngOnInit(): void {
    this.organizerName=sessionStorage.getItem('firstName');
  }
}

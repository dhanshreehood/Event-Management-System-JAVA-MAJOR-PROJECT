import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BgUserNavbarComponent } from './bg-user-navbar.component';

describe('BgUserNavbarComponent', () => {
  let component: BgUserNavbarComponent;
  let fixture: ComponentFixture<BgUserNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BgUserNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BgUserNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

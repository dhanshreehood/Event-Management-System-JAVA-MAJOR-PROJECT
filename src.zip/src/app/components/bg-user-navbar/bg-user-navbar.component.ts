import { Component } from '@angular/core';

@Component({
  selector: 'app-bg-user-navbar',
  templateUrl: './bg-user-navbar.component.html',
  styleUrls: ['./bg-user-navbar.component.css']
})
export class BgUserNavbarComponent {
  constructor() { }

  userName: any;

  ngOnInit(): void {
    this.userName=sessionStorage.getItem('firstName');
  }
}

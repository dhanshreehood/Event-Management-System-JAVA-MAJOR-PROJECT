import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';


@Component({
  selector: 'app-booking-history-user',
  templateUrl: './booking-history-user.component.html',
  styleUrls: ['./booking-history-user.component.css']
})
export class BookingHistoryUserComponent {

  booking:any;
  userId:any;

  constructor(private _router:Router, private _bookingService:BookingService) { }

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('registrationId');
    console.log(this.userId);

    this._bookingService.bookingHistoryByUserId(this.userId).subscribe(data => {console.log(data);
      this.booking=data;});
  }

  getBookingById(bookingId:number)
  {
    this._bookingService.getBookingById(bookingId).subscribe(data => {console.log(data)});
    this._router.navigate(['/updateBookingStatus/'+bookingId]);
  }
}
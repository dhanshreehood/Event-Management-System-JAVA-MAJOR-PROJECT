import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';

@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.css']
})
export class EditCategoryComponent implements OnInit {

  id:any;
  category:any;

  constructor(private _fb:FormBuilder,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _adminCategoryService:AdminCategoryService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id=params['id'];})
    
    this.category = this._adminCategoryService.getCategoryById(this.id).subscribe((response:any) => (this.category = response));
    console.log(this.id);
    console.log(this.category);
  }

  editCategoryForm:FormGroup = this._fb.group({
    categoryName:['']
  })

  editCategory()
  {
    this._adminCategoryService.editCategory(this.id,this.editCategoryForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/getAllCategory']);
    }, 1000);
  }
}

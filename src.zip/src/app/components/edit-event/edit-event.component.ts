import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminCategoryService } from 'src/app/utility/admin-category.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';

@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {

  id:any;
  event:any;

  constructor(private _fb:FormBuilder,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _eventOrganizerService:EventOrganizerService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id=params['id'];})
    
    this.event = this._eventOrganizerService.getEventById(this.id).subscribe((response:any) => (this.event = response));
    console.log(this.id);
    console.log(this.event);
  }

  editEventForm:FormGroup = this._fb.group({
    eventName:[''],
    eventDescription:[''],
    eventDate:[''],
    eventLocation:[''],
    eventPrice:['']

  })

  editEvent()
  {
    this._eventOrganizerService.editEvent(this.id,this.editEventForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/getAllEvent']);
    }, 1000);

}
}

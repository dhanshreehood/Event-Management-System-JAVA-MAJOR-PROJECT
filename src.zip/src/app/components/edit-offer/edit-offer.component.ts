import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { OfferService } from 'src/app/utility/offer.service';

@Component({
  selector: 'app-edit-offer',
  templateUrl: './edit-offer.component.html',
  styleUrls: ['./edit-offer.component.css']
})
export class EditOfferComponent {
  id:any;
  offer:any;
  constructor(private _fb:FormBuilder,private _router:Router,private _activeRoute:ActivatedRoute,private _offerService:OfferService) { }

  ngOnInit(): void {
    this._activeRoute.params.subscribe(params => {
      this.id=params['id'];})

      this.offer= this._offerService.getOfferById(this.id).subscribe((response:any) => (this.offer = response));
      console.log(this.id);
      console.log(this.offer);
  }

  editOfferForm:FormGroup = this._fb.group({
    offerName:['']
  })

  editOffer()
  {
    this._offerService.editOffer(this.id,this.editOfferForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/getAllOffer']);
    }, 1000);
  }

}

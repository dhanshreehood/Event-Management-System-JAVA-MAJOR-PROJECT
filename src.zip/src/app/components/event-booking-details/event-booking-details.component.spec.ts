import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventBookingDetailsComponent } from './event-booking-details.component';

describe('EventBookingDetailsComponent', () => {
  let component: EventBookingDetailsComponent;
  let fixture: ComponentFixture<EventBookingDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventBookingDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventBookingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

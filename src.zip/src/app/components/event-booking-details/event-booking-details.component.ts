import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { IEventOrganizer } from 'src/app/utility/IEventOrganizer';

@Component({
  selector: 'app-event-booking-details',
  templateUrl: './event-booking-details.component.html',
  styleUrls: ['./event-booking-details.component.css']
})
export class EventBookingDetailsComponent {
  data:any;
  id:any;
  events:any;

  constructor(private _activatedRoute:ActivatedRoute,private _eventOrganizerService:EventOrganizerService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id = params['id'];
      console.log("id "+this.id);
      
    // this.events = this._eventOrganizerService.getEventById(this.id);
     this._eventOrganizerService.getEventById(this.id).subscribe(data => {console.log(data);
      this.events=data;});

  });

}
}

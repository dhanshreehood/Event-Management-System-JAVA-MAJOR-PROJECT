import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventOrganizerNavbarComponent } from './event-organizer-navbar.component';

describe('EventOrganizerNavbarComponent', () => {
  let component: EventOrganizerNavbarComponent;
  let fixture: ComponentFixture<EventOrganizerNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventOrganizerNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventOrganizerNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-organizer-navbar',
  templateUrl: './event-organizer-navbar.component.html',
  styleUrls: ['./event-organizer-navbar.component.css']
})
export class EventOrganizerNavbarComponent implements OnInit {

  constructor() { }

  organizerName: any;

  ngOnInit(): void {
    this.organizerName=sessionStorage.getItem('firstName');
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginRegistrationNavbarComponent } from './login-registration-navbar.component';

describe('LoginRegistrationNavbarComponent', () => {
  let component: LoginRegistrationNavbarComponent;
  let fixture: ComponentFixture<LoginRegistrationNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginRegistrationNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginRegistrationNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

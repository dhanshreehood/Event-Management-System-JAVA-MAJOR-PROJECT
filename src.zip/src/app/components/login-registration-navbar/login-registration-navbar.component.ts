import { Component } from '@angular/core';

@Component({
  selector: 'app-login-registration-navbar',
  templateUrl: './login-registration-navbar.component.html',
  styleUrls: ['./login-registration-navbar.component.css']
})
export class LoginRegistrationNavbarComponent {

}

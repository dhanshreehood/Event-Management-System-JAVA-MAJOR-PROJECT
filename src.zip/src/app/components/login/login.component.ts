import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IRegisteredUsers } from 'src/app/utility/IRegisteredUsers';
import { LoginApiService } from 'src/app/utility/login-api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login:any;
  msg:any;

  constructor(private _service:LoginApiService, 
              private _router:Router, 
              private _fb: FormBuilder) { }

  loginForm: FormGroup = this._fb.group({
    username: ['', [Validators.required]],
    password: ['', [Validators.required]],  
  });

  ngOnInit(): void {
  }

  loginMethod(){
    this.login = this._service.login(<IRegisteredUsers>this.loginForm.value).subscribe((resp:any)=>{
      this.login = resp;
      console.log("login response",resp);
    
    console.log(this.loginForm.value);

    // setting session storage
    sessionStorage.setItem('registrationId', this.login.registrationId);
    sessionStorage.setItem('username', this.login.username);
    sessionStorage.setItem('firstName', this.login.firstName);
    sessionStorage.setItem('lastName', this.login.lastName);
    sessionStorage.setItem('role', this.login.role);

    console.log("session storage:");
    console.log('session registration id:', sessionStorage.getItem('registrationId'));
    console.log('session username:', sessionStorage.getItem('username'));
    console.log('session firstname:', sessionStorage.getItem('firstName'));
    console.log('session lastname:', sessionStorage.getItem('lastName'));
    console.log('session role:', sessionStorage.getItem('role'));

    // navigating user to it's paticular page
    if (this.login.role == "ADMIN"){
      this._router.navigate(["/adminNavbar"]);
    }
    else if (this.login.role == "ORGANIZER"){
      this._router.navigate(["/organizerNavbar"]);
    }
    else if (this.login.role == "USER"){
      this._router.navigate(["/userNavbar"]);
    }
    else if(!this.loginForm.valid){
      this._router.navigate(["/login"]);;
    }
  },

  (error)=>{
    this.msg = error;
    alert(this.msg.error);
    console.log(this.msg.error);
  }

  );
  }
}

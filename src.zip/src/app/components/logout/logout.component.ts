import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent {
  constructor(private _router:Router ) { }

  ngOnInit(): void {
   sessionStorage.removeItem('registrationId');
   sessionStorage.removeItem('username');
   sessionStorage.removeItem('firstName');
   sessionStorage.removeItem('lastName');
   sessionStorage.removeItem('role');
   sessionStorage.clear();
   setTimeout(() => this._router.navigate(['/homepage']), 1000);
  }

}
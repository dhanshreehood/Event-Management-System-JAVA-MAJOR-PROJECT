import { Component } from '@angular/core';

@Component({
  selector: 'app-main-home-page',
  templateUrl: './main-home-page.component.html',
  styleUrls: ['./main-home-page.component.css']
})
export class MainHomePageComponent {

}

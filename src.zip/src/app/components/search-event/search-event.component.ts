import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { IEventOrganizer } from 'src/app/utility/IEventOrganizer';

@Component({
  selector: 'app-search-event',
  templateUrl: './search-event.component.html',
  styleUrls: ['./search-event.component.css']
})
export class SearchEventComponent {
  searchByCategory:string="";

  events:IEventOrganizer[]=[];

  constructor(
    private _router:Router, 
    private _service:EventOrganizerService) {

   }

  ngOnInit(): void {
    
  // this.events = this._service.getAllDataEvent;
  }

}

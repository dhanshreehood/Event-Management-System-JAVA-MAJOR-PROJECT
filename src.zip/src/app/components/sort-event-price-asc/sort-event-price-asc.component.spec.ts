import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortEventPriceAscComponent } from './sort-event-price-asc.component';

describe('SortEventPriceAscComponent', () => {
  let component: SortEventPriceAscComponent;
  let fixture: ComponentFixture<SortEventPriceAscComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SortEventPriceAscComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SortEventPriceAscComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

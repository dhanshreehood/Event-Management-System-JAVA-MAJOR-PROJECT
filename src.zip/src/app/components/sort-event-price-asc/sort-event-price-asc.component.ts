import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';

@Component({
  selector: 'app-sort-event-price-asc',
  templateUrl: './sort-event-price-asc.component.html',
  styleUrls: ['./sort-event-price-asc.component.css']
})
export class SortEventPriceAscComponent {
  data:any;
  events:any;

  constructor(
    private _router:Router, 
    private _service:EventOrganizerService) {

   }

  ngOnInit(): void {

    this._service.getAllEventPriceASC().subscribe(
      data=>{console.log(data);
      this.events=data;
      })
  }
}

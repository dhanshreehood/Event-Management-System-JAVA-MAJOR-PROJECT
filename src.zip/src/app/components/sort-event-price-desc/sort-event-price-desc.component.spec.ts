import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortEventPriceDescComponent } from './sort-event-price-desc.component';

describe('SortEventPriceDescComponent', () => {
  let component: SortEventPriceDescComponent;
  let fixture: ComponentFixture<SortEventPriceDescComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SortEventPriceDescComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SortEventPriceDescComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

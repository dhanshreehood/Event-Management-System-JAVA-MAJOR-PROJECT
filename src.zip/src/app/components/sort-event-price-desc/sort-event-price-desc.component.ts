import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';

@Component({
  selector: 'app-sort-event-price-desc',
  templateUrl: './sort-event-price-desc.component.html',
  styleUrls: ['./sort-event-price-desc.component.css']
})
export class SortEventPriceDescComponent {
  data:any;
  events:any;

  constructor(
    private _router:Router, 
    private _service:EventOrganizerService) {

   }

  ngOnInit(): void {
    
    //to show all available events to the user in card format
    this._service.getAllEventPriceDESC().subscribe(
      data=>{console.log(data);
      this.events=data;
      })
  }
}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';
import { ComplaintService } from 'src/app/utility/complaint.service';

@Component({
  selector: 'app-update-booking-status',
  templateUrl: './update-booking-status.component.html',
  styleUrls: ['./update-booking-status.component.css']
})
export class UpdateBookingStatusComponent {
  id:any;
  booking:any;
  constructor(private _fb:FormBuilder,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _bookingService:BookingService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id=params['id'];})

      this.booking = this._bookingService.getBookingById(this.id).subscribe(
        (response:any) => (this.booking = response));
        console.log(this.id);
        console.log(this.booking);
  }

  updateBookingStatusForm:FormGroup = this._fb.group({
    bookingStatus:['']
  })

  updateBookingStatus()
  {
    this._bookingService.updateBookingStatus(this.id,this.updateBookingStatusForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/viewBookingStatusOrganizer']);
    }, 1000);
}
}

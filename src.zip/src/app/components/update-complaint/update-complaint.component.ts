import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ComplaintService } from 'src/app/utility/complaint.service';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';

@Component({
  selector: 'app-update-complaint',
  templateUrl: './update-complaint.component.html',
  styleUrls: ['./update-complaint.component.css']
})
export class UpdateComplaintComponent {

  id:any;
  complaint:any;
  events:any;
  constructor(private _fb:FormBuilder,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _complaintService:ComplaintService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id=params['id'];})

    this.complaint = this._complaintService.getComplaintById(this.id).subscribe(
    (response:any) => (this.complaint = response));
    console.log(this.id);
    console.log(this.complaint);
  }  

  updateComplaintForm:FormGroup = this._fb.group({
    complaintDiscription:[''],
    complaintStatus:['']

  })

  updateComplaint()
  {
    this._complaintService.updateComplaint(this.id,this.updateComplaintForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/viewComplaintToOrganizer']);
    }, 1000);
}
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent {
  id:any;
  user:any;

  constructor(private _fb:FormBuilder,
              private _router:Router,
              private _activatedRoute:ActivatedRoute, 
              private _userService:UserService) {

               }

  ngOnInit(): void {
 
    this.id=sessionStorage.getItem('registrationId');
    console.log(this.id);
    
    this.user = this._userService
    .getUserById(this.id)
    .subscribe((response:any) => (this.user = response));
    console.log(this.id);
    console.log(this.user);
  }
  updatePasswordForm:FormGroup = this._fb.group({
    userId:[''],
    password:['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
    conpassword:['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]]
  })

  updateUserPassword(){
    this._userService.updateProfile(this.id,this.updatePasswordForm.value).subscribe(
      response => {console.log(response)});
      setTimeout(() => {
      this._router.navigate(['/userNavbar']);
    }, 1000);
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent {
  user:any;

  id:any;

  constructor(private _fb:FormBuilder,
              private _router:Router,
              private _activatedRoute:ActivatedRoute, 
              private _userService:UserService) { }

  firstName: any;
  lastName:any;
  ngOnInit(): void {    

    this.id=sessionStorage.getItem('registrationId');
    console.log(this.id);

    this.firstName=sessionStorage.getItem('firstName');
    this.lastName=sessionStorage.getItem('lastName');

    this.user = this._userService.getUserById(this.id).subscribe((response:any) => (this.user = response));
  }

  updateProfileForm:FormGroup = this._fb.group({
    username:[''],
    firstName:['', [Validators.required, Validators.minLength(3)]],
    lastName:['', [Validators.required, Validators.minLength(3)]],
    email:['', [Validators.required, Validators.email]],
    address:['', [Validators.required, Validators.minLength(3)]],
    contactNumber:['',  [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
  })

  updateProfile(){
    this._userService.updateProfile(this.id,this.updateProfileForm.value).subscribe(
      response => {console.log(response)});
      setTimeout(() => {
      this._router.navigate(['/userNavbar']);
    }, 1000);
  }

}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateUserBookingStatusComponent } from './update-user-booking-status.component';

describe('UpdateUserBookingStatusComponent', () => {
  let component: UpdateUserBookingStatusComponent;
  let fixture: ComponentFixture<UpdateUserBookingStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateUserBookingStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateUserBookingStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

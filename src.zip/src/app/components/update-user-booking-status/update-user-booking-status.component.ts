import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';

@Component({
  selector: 'app-update-user-booking-status',
  templateUrl: './update-user-booking-status.component.html',
  styleUrls: ['./update-user-booking-status.component.css']
})
export class UpdateUserBookingStatusComponent {
  id:any;
  booking:any;
  constructor(private _fb:FormBuilder,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _bookingService:BookingService) { }

  ngOnInit(): void {
    this._activatedRoute.params.subscribe(params => {
      this.id=params['id'];})

      this.booking = this._bookingService.getBookingById(this.id).subscribe(
        (response:any) => (this.booking = response));
        console.log(this.id);
        console.log(this.booking);
  }

  updateBookingStatusByUserForm:FormGroup = this._fb.group({
    userBookingStatus:['']
  })

  updateUserStatus()
  {
    this._bookingService.updateUserStatus(this.id,this.updateBookingStatusByUserForm.value).subscribe(response => {console.log(response)});
    setTimeout(() => {
      this._router.navigate(['/UserbookingHistory']);
    }, 1000);
}
}

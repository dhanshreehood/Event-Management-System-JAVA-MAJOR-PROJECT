import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBookingStatusOrganizerComponent } from './view-booking-status-organizer.component';

describe('ViewBookingStatusOrganizerComponent', () => {
  let component: ViewBookingStatusOrganizerComponent;
  let fixture: ComponentFixture<ViewBookingStatusOrganizerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBookingStatusOrganizerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewBookingStatusOrganizerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from 'src/app/utility/booking.service';
import { ComplaintService } from 'src/app/utility/complaint.service';

@Component({
  selector: 'app-view-booking-status-organizer',
  templateUrl: './view-booking-status-organizer.component.html',
  styleUrls: ['./view-booking-status-organizer.component.css']
})
export class ViewBookingStatusOrganizerComponent {
  booking:any;
  organizerId:any;

  constructor(private _router:Router, private _bookingService:BookingService) { }

  ngOnInit(): void {

    //get organizer data by organizer id
    this.organizerId=sessionStorage.getItem('registrationId');
    console.log(this.organizerId);

    this._bookingService.getBookingHistoryByOrganizerId(this.organizerId).subscribe(data => {console.log(data);
      this.booking=data;});
  }

  getBookingById(bookingId:number)
  {
    this._bookingService.getBookingById(bookingId).subscribe(data => {console.log(data)});
    this._router.navigate(['/updateBookingStatus/'+bookingId]);
  }
}
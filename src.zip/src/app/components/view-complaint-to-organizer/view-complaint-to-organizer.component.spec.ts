import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewComplaintToOrganizerComponent } from './view-complaint-to-organizer.component';

describe('ViewComplaintToOrganizerComponent', () => {
  let component: ViewComplaintToOrganizerComponent;
  let fixture: ComponentFixture<ViewComplaintToOrganizerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewComplaintToOrganizerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewComplaintToOrganizerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

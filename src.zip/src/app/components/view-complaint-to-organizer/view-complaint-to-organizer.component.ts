import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ComplaintService } from 'src/app/utility/complaint.service';

@Component({
  selector: 'app-view-complaint-to-organizer',
  templateUrl: './view-complaint-to-organizer.component.html',
  styleUrls: ['./view-complaint-to-organizer.component.css']
})
export class ViewComplaintToOrganizerComponent {

  complaints:any;

  constructor(private _router:Router, private _complaintService:ComplaintService) { }

  ngOnInit(): void {
    this._complaintService.getAllComplaints().subscribe(data => {console.log(data);
      this.complaints=data;});
  }

  getEventById(complaintId:number)
  {
    this._complaintService.getComplaintById(complaintId).subscribe(data => {console.log(data)});
    this._router.navigate(['/updateComplaint/'+complaintId]);
  }

}

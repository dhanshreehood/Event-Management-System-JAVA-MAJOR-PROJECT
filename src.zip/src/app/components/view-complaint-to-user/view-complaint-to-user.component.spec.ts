import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewComplaintToUserComponent } from './view-complaint-to-user.component';

describe('ViewComplaintToUserComponent', () => {
  let component: ViewComplaintToUserComponent;
  let fixture: ComponentFixture<ViewComplaintToUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewComplaintToUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewComplaintToUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

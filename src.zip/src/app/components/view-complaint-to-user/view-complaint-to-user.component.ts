import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ComplaintService } from 'src/app/utility/complaint.service';

@Component({
  selector: 'app-view-complaint-to-user',
  templateUrl: './view-complaint-to-user.component.html',
  styleUrls: ['./view-complaint-to-user.component.css']
})
export class ViewComplaintToUserComponent {

  complaints:any;
  userId:any;

  constructor(private _router:Router, 
    private _complaintService:ComplaintService) { }

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('registrationId');-
    console.log(this.userId);
    this._complaintService.getComplaintByUserId(this.userId).subscribe(data => {console.log("data =>"+typeof data);
      this.complaints=data;});
  }

}

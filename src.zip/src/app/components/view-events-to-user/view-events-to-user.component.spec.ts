import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEventsToUserComponent } from './view-events-to-user.component';

describe('ViewEventsToUserComponent', () => {
  let component: ViewEventsToUserComponent;
  let fixture: ComponentFixture<ViewEventsToUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEventsToUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewEventsToUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

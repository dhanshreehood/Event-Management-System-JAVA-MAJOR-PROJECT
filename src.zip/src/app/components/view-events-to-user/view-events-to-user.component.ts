import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventOrganizerService } from 'src/app/utility/event-organizer.service';
import { IEventOrganizer } from 'src/app/utility/IEventOrganizer';

@Component({
  selector: 'app-view-events-to-user',
  templateUrl: './view-events-to-user.component.html',
  styleUrls: ['./view-events-to-user.component.css']
})
export class ViewEventsToUserComponent {
  data:any;
  events:any;

  searchByEventName:string="";
  
  eventName:IEventOrganizer[]=[];

  constructor(
    private _router:Router, 
    private _service:EventOrganizerService) {

   }

  ngOnInit(): void {
    
    this._service.getAllEvent().subscribe(data => {console.log(data);
      this.events=data;});
   
  }
}
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatSidenavModule} from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import {MatListModule} from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import { UserNavbarComponent } from '../components/user-navbar/user-navbar.component';


const material=[
  MatSidenavModule,
  MatToolbarModule,
  MatButtonModule,
  MatListModule,
  MatIconModule,
  MatFormFieldModule,
  MatCardModule,
  MatSelectModule,
  MatInputModule
]


@NgModule({
  declarations: [
    UserNavbarComponent
  ],
  imports: [
    CommonModule,
    material
  ],

  //exporting it so that we can use it in the main app module, then we will import it in app.module.ts
  exports:[material]
})
export class MaterialModule { }

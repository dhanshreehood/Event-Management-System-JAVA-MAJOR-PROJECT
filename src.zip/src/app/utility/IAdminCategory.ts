
export interface IAdminCategory {
    categoryId:number;
    categoryName:string;
    admin:object;
}
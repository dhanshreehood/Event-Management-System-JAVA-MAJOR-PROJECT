export interface IBooking {
    bookingId:number;
    bookingStatus:string;
    userBookingStatus:string;
    event:object;
    user:object;
    offer:object;
    eventOrganizer:object;
}
export interface IComplaint {
    complaintId:number;
    complaintDiscription:string;
    complaintStatus:string;
    userComplaint:object;
    eventNameId:object;
    eventOrganizer:object;
}
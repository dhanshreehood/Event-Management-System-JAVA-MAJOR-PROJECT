export interface IEventOrganizer {
    eventId:number;
    eventCategory:object;
    eventName:string;
    eventDescription:string
    eventDate:Date;
    eventLocation:string;
    eventPrice:number;
    eventOrganizer:object;
}
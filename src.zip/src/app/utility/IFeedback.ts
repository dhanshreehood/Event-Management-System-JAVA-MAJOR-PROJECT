export interface IFeedback {
    feedbackId:number;
    rating:string;
    feedback:string;
}
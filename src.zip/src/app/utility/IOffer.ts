
export interface IOffer {
    offerId:number;
    offerName:string;
    eventOrganizer:object;
}
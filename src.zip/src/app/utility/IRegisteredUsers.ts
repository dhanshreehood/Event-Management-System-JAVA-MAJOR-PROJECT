export interface IRegisteredUsers {
    registrationId:number;
    username:string;
    firstName:string;
    lastName:string;
    email:string;
    password:string;
    address:string;
    contactNumber:string;
    role:string;
    validate:boolean;
    verificationStatus:string;
}
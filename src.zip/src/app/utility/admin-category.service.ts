import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IAdminCategory } from './IAdminCategory';

@Injectable({
  providedIn: 'root'
})
export class AdminCategoryService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/category"

  category:any;

  addCategory(category:any)
  {
      return this._httpClient.post(this.baseUrl+"/",category, {responseType: 'JSON' as 'text'});
  }

  getAllCategory():Observable<IAdminCategory>
  {
     return this._httpClient.get<IAdminCategory>(this.baseUrl+"/");
  }

  getCategoryById(categoryId:number)
  { 
      return this._httpClient.get(this.baseUrl+"/"+categoryId);
  }

  editCategory(categoryId:number,category:IAdminCategory)
  {
      return this._httpClient.put(this.baseUrl+"/"+categoryId,category,{responseType: 'JSON' as 'text'});
  }

  deleteCategory(categoryId:number)
  {
      return this._httpClient.delete(this.baseUrl+"/"+categoryId,{responseType: 'JSON' as "text"});
  }


}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEventOrganizer } from './IEventOrganizer';
import { IRegisteredUsers } from './IRegisteredUsers';

@Injectable({
  providedIn: 'root'
})
export class AllRegisteredUsersService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/mainSystem"

  registeredUsers:any;

  getByOrganizer()
  { 
      return this._httpClient.get(this.baseUrl+"/getByOrganizer/");
  }

  getByUser()
  { 
      return this._httpClient.get(this.baseUrl+"/getByUser/");
  }

  deleteUser(eventId:number)
  {
      return this._httpClient.delete(this.baseUrl+"/deleteById/"+eventId,{responseType: 'JSON' as "text"});
  }

}

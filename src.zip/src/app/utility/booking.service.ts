import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IBooking } from './IBooking';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class BookingService {
  constructor(private _httpClient:HttpClient) { }

  bookingUrl:string="http://localhost:8080/booking"

  booking:any;

  addBooking(booking:any)
  {
      return this._httpClient.post(this.bookingUrl+"/addBooking",booking, {responseType: 'JSON' as 'text'});
  }

  deleteBookingById(bookingId:number)
  {
      return this._httpClient.delete(this.bookingUrl+"/deleteBookingById/"+bookingId, {responseType: 'JSON' as "text"});
  }

  updateBookingStatus(bookingId:number, booking:IBooking)
  {
      return this._httpClient.put(this.bookingUrl+"/updateBookingStatus/"+bookingId, booking,{responseType: 'JSON' as 'text'});
  }

  getAllBooking()
  {
    return this._httpClient.get<IBooking>(this.bookingUrl+"/getAllBooking");

  }

  getBookingById(bookingId:number)
  {
    return this._httpClient.get(this.bookingUrl+"/getBookingById/"+bookingId);
  }

  updateUserStatus(bookingId:number, booking:IBooking)
  {
    return this._httpClient.put(this.bookingUrl+"/updateUserStatus/"+bookingId, booking,{responseType: 'JSON' as 'text'});
  }

  bookingHistoryByUserId(registrationId:number):Observable<any>
  {
    return this._httpClient.get(this.bookingUrl+"/bookingHistoryByUserId/"+registrationId);
  }

  getBookingHistoryByOrganizerId(organizerId:number):Observable<any>
  {
    return this._httpClient.get(this.bookingUrl+"/getBookingHistoryByOrganizerId/"+organizerId);

  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IComplaint } from './IComplaint';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/complaint"

  complaint:any;

  addComplaint(complaint:any)
  {
      return this._httpClient.post(this.baseUrl+"/addComplaint",complaint, {responseType: 'JSON' as 'text'});
  }

  getAllComplaints():Observable<IComplaint>
  {
     return this._httpClient.get<IComplaint>(this.baseUrl+"/getAllComplaints/");
  }

  getComplaintById(complaintId:number)
  { 
      return this._httpClient.get(this.baseUrl+"/getComplaintById/"+complaintId);
  }

  updateComplaint(complaintId:number,complaint:IComplaint)
  {
      return this._httpClient.put(this.baseUrl+"/updateComplaint/"+complaintId,complaint,{responseType: 'JSON' as 'text'});
  }

  deleteComplaintById(complaintId:number)
  {
      return this._httpClient.delete(this.baseUrl+"/deleteComplaintById/"+complaintId,{responseType: 'JSON' as "text"});
  }

  //get Event List By OrganizerId
  getComplaintByUserId(registrationId:number):Observable<any>
  {
    return this._httpClient.get(this.baseUrl+"/getComplaintByUserId/"+registrationId);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEventOrganizer } from './IEventOrganizer';


@Injectable({
  providedIn: 'root'
})
export class EventOrganizerService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/event"

  event:any;

  addEvent(event:any)
  {
      return this._httpClient.post(this.baseUrl+"/",event, {responseType: 'JSON' as 'text'});
  }

  getAllEvent():Observable<IEventOrganizer>
  {
     return this._httpClient.get<IEventOrganizer>(this.baseUrl+"/");
  }

  getEventById(eventId:number)
  { 
      return this._httpClient.get(this.baseUrl+"/"+eventId);
  }

  editEvent(eventId:number,event:IEventOrganizer)
  {
      return this._httpClient.put(this.baseUrl+"/"+eventId,event,{responseType: 'JSON' as 'text'});
  }

  deleteEvent(eventId:number)
  {
      return this._httpClient.delete(this.baseUrl+"/"+eventId,{responseType: 'JSON' as "text"});
  }

  getAllDataEvent()
  {
     return this._httpClient.get<IEventOrganizer>(this.baseUrl+"/");
  }

  getAllEventPriceDESC(){
    return this._httpClient.get<IEventOrganizer>(this.baseUrl+"/priceFromDesc");
  }

  getAllEventPriceASC(){
    return this._httpClient.get<IEventOrganizer>(this.baseUrl+"/priceFromAsc");
  }

  //get Event List By OrganizerId
  getEventListByOrganizerId(registrationId:number):Observable<any>
  {
    return this._httpClient.get(this.baseUrl+"/getEventListById/"+registrationId);
  }
}
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IFeedback } from './IFeedback';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/mainSystemFeedback"

  feedback:any;

  addFeedback(feedback:any)
  {
      return this._httpClient.post(this.baseUrl+"/addFeedback",feedback, {responseType: 'JSON' as 'text'});
  }

  getAllFeedback():Observable<IFeedback>
  {
     return this._httpClient.get<IFeedback>(this.baseUrl+"/getAllFeedback/");
  }

  getFeedbackById(feedbackId:number)
  { 
      return this._httpClient.get(this.baseUrl+"/getFeedbackById/"+feedbackId);
  }
}

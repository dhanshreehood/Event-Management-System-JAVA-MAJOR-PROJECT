import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IRegisteredUsers } from './IRegisteredUsers';

@Injectable({
  providedIn: 'root'
})
export class LoginApiService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/login";

  login(user: IRegisteredUsers)
  {
      return this._httpClient.post(this.baseUrl+"/", user);
  }

}

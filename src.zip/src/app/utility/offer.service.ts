import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IOffer } from './IOffer';

@Injectable({
  providedIn: 'root'
})
export class OfferService {

  constructor(private _httpClient:HttpClient) { }
  baseUrl:string="http://localhost:8080/offer"

  offer:any;

  addOffer(offer:any)
  {
    return this._httpClient.post(this.baseUrl+"/",offer,{responseType:'JSON' as 'text'});
  }

  getAllOffer():Observable<IOffer>
  {
    return this._httpClient.get<IOffer>(this.baseUrl+"/");
  }

  getOfferById(offerId:number)
  { 
      return this._httpClient.get(this.baseUrl+"/"+offerId);
  }

  editOffer(offerId:number,offer:IOffer)
  {
    return this._httpClient.put(this.baseUrl+"/"+offerId,offer,{responseType:'Json' as 'text'});
  }

  deleteOffer(offerId:number)
  {
    return this._httpClient.delete(this.baseUrl+"/"+offerId,{responseType:'Json' as 'text'});
  }

    //get offer List By OrganizerId
    getOfferByOrganizerId(registrationId:number):Observable<any>
    {
      return this._httpClient.get(this.baseUrl+"/getOfferByOrganizerId/"+registrationId);
    }
}

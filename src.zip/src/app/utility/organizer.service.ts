import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEventOrganizer } from './IEventOrganizer';

@Injectable({
  providedIn: 'root'
})
export class OrganizerService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/mainSystem"

  registeredUsers:any;

  getByOrganizer():Observable<IEventOrganizer>
  { 
      return this._httpClient.get<IEventOrganizer>(this.baseUrl+"/getByOrganizer");
  }

  deleteById(registrationId:number)
  {
      return this._httpClient.delete(this.baseUrl+"/deleteById/"+registrationId,{responseType: 'JSON' as "text"});
  }

}

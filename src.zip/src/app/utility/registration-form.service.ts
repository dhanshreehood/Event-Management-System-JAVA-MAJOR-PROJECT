import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RegistrationFormService {

  constructor(private _httpClient:HttpClient) { }

  baseUrl:string="http://localhost:8080/mainSystem"

  register:any;

  registration(register:any)
  {
      return this._httpClient.post(this.baseUrl+"/register",register, {responseType: 'JSON' as 'text'});
  }
}

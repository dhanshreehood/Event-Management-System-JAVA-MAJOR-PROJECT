import { Pipe, PipeTransform } from '@angular/core';
import { IEventOrganizer } from './IEventOrganizer';

@Pipe({
  name: 'searchEvents'
})
export class SearchPipe implements PipeTransform {

  transform(events: IEventOrganizer[], args:string): IEventOrganizer[] {
    let searchStr:string = args.toLocaleLowerCase();
    return events.filter(event => {
      let eventName = event.eventName.toLocaleLowerCase()
      return eventName.indexOf(searchStr) !== -1
    });
  }

}

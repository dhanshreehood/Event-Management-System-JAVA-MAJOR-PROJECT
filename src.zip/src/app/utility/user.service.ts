import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IRegisteredUsers } from './IRegisteredUsers';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl:string="http://localhost:8080/mainSystem"

  constructor(private _httpClient:HttpClient) { }

  getUserById(id:number):Observable<IRegisteredUsers>
  {
    return this._httpClient.get<IRegisteredUsers>(this.baseUrl + "/getUserById/" +id);
  }

   updateProfile(id:number, user:IRegisteredUsers):Observable<IRegisteredUsers>
  {
    return this._httpClient.put<IRegisteredUsers>(this.baseUrl+"/updateById/"+id, user);
  }

}
